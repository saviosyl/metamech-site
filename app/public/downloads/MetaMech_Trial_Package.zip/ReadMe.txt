MetaMech Trial Package

1) Replace placeholder with MetaMechTrial.exe
2) Read MetaMech_Trial_QuickStart.pdf

Support: hi@metamechsolutions.com
